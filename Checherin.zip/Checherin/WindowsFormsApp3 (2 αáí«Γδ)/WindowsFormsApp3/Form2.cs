﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s1 = "Первый";
            string s11 = "Компьютерные сети";
            string s2 = "2Второ";
            string s22 = "Электронные сети";
            string s3 = "Третий";
            string s33 = "Что-то там третье";

            if (comboBox1.SelectedIndex == 0)
            {
                textBox1.Text = Convert.ToString(s1);
                textBox2.Text = Convert.ToString(s11);
            }
            if (comboBox1.SelectedIndex == 1)
            {
                textBox1.Text = Convert.ToString(s2);
                textBox2.Text = Convert.ToString(s22);
            }
            if (comboBox1.SelectedIndex == 2)
            {
                textBox1.Text = Convert.ToString(s3);
                textBox2.Text = Convert.ToString(s33);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
