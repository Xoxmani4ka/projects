﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadazcha14Checherin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int s1 = 0;
            if (radioButton1.Checked == true)
            { s1 = 1000; }

            string km = textBox1.Text;
            int km1 = Convert.ToInt32(km);
            int itog = km1 * 100 + s1;

            textBox2.Text = Convert.ToString(itog);
        }
    }
    }
}
