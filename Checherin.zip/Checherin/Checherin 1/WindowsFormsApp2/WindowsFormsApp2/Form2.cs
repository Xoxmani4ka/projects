﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        int t = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            t = t + 1;
            if (t == 1)
            {
                label2.Visible = true;
                label2.Text = "А может ты выберешь пунктик?";
            }
            else if (t == 2)
            {
                label3.Visible = true;
                label3.Text = "Алло, выбирай!";
            }
        }
    }
}
