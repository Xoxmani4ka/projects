﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int etaj = Convert.ToInt32(textBox1.Text);
            if (listBox1.SelectedIndex == 0)
            {
                int con = etaj * 25;
                textBox2.Text = Convert.ToString(con);
            }
            else if (listBox1.SelectedIndex == 1)
            {
                int con = etaj * 20;
                textBox2.Text = Convert.ToString(con);
            }
            else if (listBox1.SelectedIndex == 2)
            {
                int con = etaj * 10;
                textBox2.Text = Convert.ToString(con);
            }
        }
    }
}
