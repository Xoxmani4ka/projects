﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0) 
            {
                textBox3.Text = "Первый курс";
                textBox2.Text = "Земельно Имущественные Отношения";
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                textBox3.Text = "Второй курс";
                textBox2.Text = "Электронные Сети";
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                textBox3.Text = "Третий курс";
                textBox2.Text = "Компьютерные сети";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
    }
}
