﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var sum = Convert.ToInt32(textBox1.Text);
            string simb = "rub";

            if (radioButton1.Checked)
            {
                if (radioButton4.Checked)
                {
                    textBox2.Text = Convert.ToString(sum / 1);
                }
                if (radioButton5.Checked)
                {
                    textBox2.Text = Convert.ToString(sum / 66);
                }
                if (radioButton6.Checked)
                {
                    textBox2.Text = Convert.ToString(sum / 104);
                }
            }
            if (radioButton2.Checked)
            {
                if (radioButton4.Checked)
                {
                    textBox2.Text = Convert.ToString(sum * 66);
                }
                if (radioButton5.Checked)
                {
                    textBox2.Text = Convert.ToString(sum * 1);
                }
                if (radioButton6.Checked)
                {
                    textBox2.Text = Convert.ToString(sum * 1.5757);
                }
            }
            else if (radioButton3.Checked)
            {
                if (radioButton4.Checked)
                {
                    textBox2.Text = Convert.ToString(sum * 104);
                }
                if (radioButton5.Checked)
                {
                    textBox2.Text = Convert.ToString(sum * 1.5757);
                }
                if (radioButton6.Checked)
                {
                    textBox2.Text = Convert.ToString(sum / 1);
                }
            }
        }
    }
}
